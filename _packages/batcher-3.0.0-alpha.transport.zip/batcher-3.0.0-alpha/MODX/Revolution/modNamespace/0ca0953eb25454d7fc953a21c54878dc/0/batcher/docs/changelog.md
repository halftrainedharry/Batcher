# Changelog for Batcher

## Batcher 3.0.0

- Rewrite for MODX 3

## Batcher 2.0.0

- Added advanced filter option to Resources tab
- Added empty value to template filter combobox
- Added filter by context
- Templates tab is replaced by Elements tab
- Added Dutch translation
- Removed functionality to change TV values

## Batcher 1.2.0

- Fixes for MODX 2.2

## Batcher 1.1.1

- Fixes for MODX 2.1

## Batcher 1.1.0

- Added fix for bug with Firefox and batch editing
- Updated Russian translation
- Added batch change TV default values for a Template
- Added batch change TV values for all Resources in a Template
- Added batch change Template category

## Batcher 1.0.1

- Fixed bug with changeDates due to Revo RC-3 changes
- Added German translation
- Added French translation

## Batcher 1.0.0

- Added Russian translation
- Initial commit